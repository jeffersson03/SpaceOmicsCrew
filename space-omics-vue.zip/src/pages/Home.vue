
<template>
  <section class="container" style="text-align:center;padding-top:2rem;">
    <h1 style="font-size:3rem; font-weight:900; background:linear-gradient(135deg,var(--accent1),var(--bg3),var(--accent2)); -webkit-background-clip:text; -webkit-text-fill-color:transparent;">
      Plant Resilience Repository
    </h1>
    <p class="muted" style="max-width:800px;margin:0 auto 2rem;">
      Descubre cómo las plantas se adaptan a condiciones extremas en misiones espaciales.
    </p>
    <div style="max-width:600px;margin:0 auto 2rem;">
      <input v-model="q" placeholder="Busca especie o gen…" 
             style="width:100%;padding:0.9rem 1rem;border-radius:999px;border:1px solid rgba(255,255,255,.2);background:rgba(198,185,255,.08);color:var(--text);"/>
    </div>

    <h2 style="color:var(--accent1)">Especies recientemente añadidas</h2>
    <div class="grid grid-3" style="margin-top:1rem;">
      <div v-for="s in filteredEspecies" :key="s.especie_id" class="card">
        <div style="display:flex;align-items:center;gap:1rem;">
          <div style="width:44px;height:44px;border-radius:12px;background:linear-gradient(135deg,var(--accent2),var(--accent1));"></div>
          <div>
            <div style="font-weight:700;color:var(--accent1)">{{ s.nombre_cientifico }}</div>
            <div class="muted">{{ s.nombre_comun }}</div>
          </div>
        </div>
        <div style="display:flex;gap:.5rem;margin-top:.75rem;flex-wrap:wrap;">
          <span class="pill">Familia: {{ s.familia }}</span>
          <span class="pill">Parte: {{ s.parte_comestible }}</span>
          <span class="pill">Vía: {{ s.via_fotosintesis }}</span>
        </div>
      </div>
    </div>
  </section>
</template>

<script setup>
import { ref, computed, onMounted } from 'vue'
import { getEspecies } from '../services/api'
const especies = ref([])
const q = ref('')
const filteredEspecies = computed(() => {
  const qq = q.value.trim().toLowerCase()
  return especies.value.filter(e => !qq || e.nombre_cientifico.toLowerCase().includes(qq) || e.nombre_comun.toLowerCase().includes(qq))
})
onMounted(async () => { especies.value = await getEspecies() })
</script>
