
<template>
  <section class="container" style="padding-top:1rem;">
    <div style="display:flex;align-items:end;justify-content:space-between;gap:1rem;flex-wrap:wrap;">
      <div>
        <h1 style="font-size:2rem;font-weight:900;background:linear-gradient(135deg,var(--accent1),var(--bg3),var(--accent2));-webkit-background-clip:text;-webkit-text-fill-color:transparent;">
          Comparador de KPIs por Especie
        </h1>
        <p class="muted">Rendimiento, días a cosecha, pH y EC por experimento.</p>
      </div>
      <div style="display:flex;gap:.5rem;">
        <button class="btn btn-primary" @click="exportCSV">Descargar CSV</button>
      </div>
    </div>

    <div class="card" style="margin-top:1rem;overflow:auto;">
      <table>
        <thead>
          <tr>
            <th>Especie</th>
            <th>Rendimiento (g/m²/d)</th>
            <th>Días a Cosecha</th>
            <th>pH</th>
            <th>EC (mS/cm)</th>
            <th>Acción</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="r in rows" :key="r.experimento_id">
            <td>
              <div style="display:flex;align-items:center;gap:.75rem;">
                <div style="width:36px;height:36px;border-radius:50%;background:linear-gradient(135deg,var(--accent2),var(--accent1));"></div>
                <div>
                  <div style="font-weight:700;color:var(--accent1)">{{ r.especie_cientifico }}</div>
                  <div class="muted">{{ r.especie_comun }}</div>
                </div>
              </div>
            </td>
            <td>{{ r.rendimiento ?? '—' }}</td>
            <td>{{ r.dias_cosecha ?? '—' }}</td>
            <td>{{ r.ph ?? '—' }}</td>
            <td>{{ r.ec ?? '—' }}</td>
            <td><router-link :to="`/investigacion/${r.experimento_id}`" class="btn btn-secondary">Ver ficha</router-link></td>
          </tr>
        </tbody>
      </table>
    </div>
  </section>
</template>

<script setup>
import { onMounted, ref } from 'vue'
import { getKPIComparadorRows } from '../services/api'
const rows = ref([])
onMounted(async () => { rows.value = await getKPIComparadorRows() })
function exportCSV(){
  const headers = ['experimento_id','especie_cientifico','especie_comun','rendimiento','dias_cosecha','ph','ec']
  const lines = [headers.join(',')].concat(rows.value.map(r=>headers.map(h=>r[h] ?? '').join(',')))
  const blob = new Blob([lines.join('\n')], {type:'text/csv;charset=utf-8;'})
  const url = URL.createObjectURL(blob)
  const a = document.createElement('a'); a.href=url; a.download='comparador.csv'; a.click(); URL.revokeObjectURL(url)
}
</script>
