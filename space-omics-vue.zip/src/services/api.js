
// Mock-first API service. Replace the mock fetchers with real HTTP calls later.
import mock from '../data/mock.json'

export async function getEspecies() {
  return mock.especies
}

export async function getExperimentos() {
  return mock.experimentos
}

export async function getResultados() {
  return mock.resultados
}

export async function getConjuntosOmicos() {
  return mock.conjuntos_omicos
}

export async function getFuentes() {
  return mock.fuentes
}

export async function getMarcadores() {
  return mock.marcadores
}

export async function getExpMarcadores() {
  return mock.experimento_marcador
}

export async function getPerfilNutricional() {
  return mock.perfil_nutricional
}

// Handy aggregator joins for the UI (client-side for now)
export async function getKPIComparadorRows() {
  const [exp, res, esp] = await Promise.all([getExperimentos(), getResultados(), getEspecies()])
  const rows = exp.map(e => {
    const r = res.find(rr => rr.experimento_id === e.experimento_id)
    const s = esp.find(ss => ss.especie_id === e.especie_id)
    return {
      experimento_id: e.experimento_id,
      especie_cientifico: s?.nombre_cientifico || '—',
      especie_comun: s?.nombre_comun || '—',
      rendimiento: r?.rendimiento_g_m2_d ?? null,
      dias_cosecha: r?.dias_cosecha ?? null,
      ph: e.env_ph ?? null,
      ec: e.env_ec_conductividad ?? null
    }
  })
  return rows
}

export async function getFichaByExperimento(id) {
  const [exp, res, esp, fu, om] = await Promise.all([getExperimentos(), getResultados(), getEspecies(), getFuentes(), getConjuntosOmicos()])
  const ex = exp.find(x => String(x.experimento_id) === String(id))
  if (!ex) return null
  const r = res.find(rr => rr.experimento_id === ex.experimento_id)
  const s = esp.find(ss => ss.especie_id === ex.especie_id)
  const f = fu.find(ff => ff.fuente_id === ex.fuente_id)
  const omics = om.filter(o => o.experimento_id === ex.experimento_id)
  return { experimento: ex, resultado: r || {}, especie: s || {}, fuente: f || {}, omics }
}
